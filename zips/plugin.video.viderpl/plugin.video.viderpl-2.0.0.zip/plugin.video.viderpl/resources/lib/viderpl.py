# -*- coding: utf-8 -*-
import sys,os

import re
import xbmc,xbmcaddon, xbmcvfs, xbmcgui

import json
import requests

import base64
try:
	import http.cookiejar as cookielib
except ImportError:
	import cookielib

PY3 = sys.version_info >= (3,0,0)
if sys.version_info >= (3,0,0):

	unicode = str	
addon = xbmcaddon.Addon(id='plugin.video.viderpl')

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'
BASEURL='https://vider.info'
TIMEOUT = 60
my_addon = xbmcaddon.Addon(id='plugin.video.viderpl')


PATH			= my_addon.getAddonInfo('path')
if sys.version_info[0] > 2:
	DATAPATH		= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
else:
	DATAPATH		= xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
	
RESOURCES	   = PATH+'/resources/'
COOKIEFILE = os.path.join(DATAPATH,'vider.cookie')

sess = requests.Session()#

sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)
def getCook():
	sess.cookies.clear()


	headersx = {
		'Host': 'vider.info',
		'user-agent': UA,
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'content-type': 'application/x-www-form-urlencoded',
		'referer': 'http://vider.info/',
		'origin': 'http://vider.info',
		'upgrade-insecure-requests': '1',
		'te': 'trailers',
	}

	response = sess.get('http://vider.info', headers=headersx, verify=False)#.content
	sess.cookies.save(COOKIEFILE, ignore_discard = True)
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in response.cookies])
	addon.setSetting('kukz', sc)
	return sc
def getUrl(url,data=None,headers={},cookies=None, is_json=False):
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load(COOKIEFILE)

	html = ''
	if headers:
		my_header=headers
	else:
		my_header = {'User-Agent':UA}

	cook = addon.getSetting('kukz')
	my_header.update({'Cookie': cook})
	try:
		if data:
			if is_json:
				response = sess.post(url, headers=my_header, json=data, cookies=sess.cookies, verify=False)
			else:
				response = sess.post(url, headers=my_header, data=data, cookies=sess.cookies, verify=False)
			return response.text
		else:
			response = sess.get(url, headers=my_header, cookies=sess.cookies, verify=False)
			xbmc.log('[VIDER] HTTP %s -> %s' % (response.status_code, url), xbmc.LOGINFO)
			return response.text
	except Exception as e:
		xbmc.log('[VIDER] Request error: %s' % str(e), xbmc.LOGERROR)
		return ''
def rozwCaptcha(html):

	if os.path.isfile(COOKIEFILE):
		sess.cookies.load(COOKIEFILE)

	headers = {
		'Host': 'vider.info',
		'user-agent': UA,
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'dnt': '1',
		'upgrade-insecure-requests': '1',
		'te': 'trailers',
	}

	headersx = {
		'Host': 'vider.info',
		'user-agent': UA,
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'content-type': 'application/x-www-form-urlencoded',
		'referer': 'https://vider.info/',
		'origin': 'https://vider.info',
		'upgrade-insecure-requests': '1',
		'te': 'trailers',
	}

	response = sess.get(
		'https://vider.info/',
		headers=headers,
		cookies=sess.cookies,
		verify=False
	)

	html = response.text

	capurl = re.findall(r'"(\/streaming\/ca.+?)"', html)
	if not capurl:
		xbmcgui.Dialog().ok(
			'Vider',
			'Nie znaleziono adresu obrazka captcha.'
		)
		return ''

	capurl = 'https://vider.info' + capurl[0]

	response = sess.get(
		capurl,
		headers=headersx,
		cookies=sess.cookies,
		verify=False
	)

	profile_path = DATAPATH

	if not os.path.exists(profile_path):
		os.makedirs(profile_path)

	temp_img_path = os.path.join(profile_path, 'captcha.png')

	try:
		with open(temp_img_path, 'wb') as f:
			f.write(response.content)
	except Exception as e:
		xbmcgui.Dialog().ok(
			'Błąd Captcha',
			'Nie udało się zapisać obrazka:\n%s' % str(e)
		)
		return ''

	xbmc.executebuiltin('ShowPicture(' + temp_img_path + ')')
	xbmc.sleep(1000)

	keyboard = xbmc.Keyboard(
		'',
		'Wpisz kod z obrazka:',
		False
	)

	keyboard.doModal()

	captcha_code = (
		keyboard.getText()
		if keyboard.isConfirmed()
		else ''
	)

	xbmc.executebuiltin('Action(Back)')

	if not captcha_code:
		return ''

	data = {'captcha': captcha_code}

	response = sess.post(
		'https://vider.info/',
		headers=headersx,
		data=data,
		cookies=sess.cookies,
		verify=False
	)

	sess.cookies.save(COOKIEFILE, ignore_discard=True)

	sc = ''.join(
		['%s=%s;' % (c.name, c.value) for c in response.cookies]
	)

	addon.setSetting('kukz', sc)

	return sc
def _get_overflowtype(overflow):
	out=[]
	item = overflow[0]

	for item in overflow:
		href = re.compile('<a href="(.*?)"\s*>').findall(item)
		
		img = re.compile('<img src="(.*?)">').findall(item)
		title = re.compile('<span class="txt_md">(.*?)</span>').findall(item)
		duration = re.compile('<i class="fa fa-clock-o"></i>(.*?)</span>',).findall(item)
		if href and title:
		   #if PY3:
		   #	one = {'href'   : (BASEURL+href[0]),#.decode("utf-8"),
		   #		'title' : (unicodePLchar(title[0]).strip()).decode("utf-8") if title else '',
		   #		'img' : (img[0]).decode("utf-8"),
		   #		'duration': (duration[0].strip()).decode("utf-8") if duration else ''
		   #		}
		  #  else:	
			one = {'href'   : BASEURL+href[0],
				'title' : unicodePLchar(title[0]).strip() if title else '',
				'img' : img[0],
				'duration': duration[0].strip() if duration else ''
				}
			out.append(one)
	return out
def _get_clearfixtype(clearfix):
	out=[]

	for item in clearfix:
		href_title = re.compile('<a href="(.+?)"\s*class=".*"\s*>(.*?)</a>').findall(item)
		img = re.compile('<img src="(.*?)" ').findall(item)
		meta = re.compile('<p class="meta">(.*?)</p>',re.DOTALL).findall(item)
		duration = re.compile('<div class="duration">(.*?)</div>').findall(item)
		plot = re.compile('<p class="description">(.*?)</p>').findall(item)
		status = re.findall('<div class="float-r badge_new">(.*?)</div>',item)
		if href_title:
			folder =''
			if meta:

				txt = ' '.join(x.strip() for x in re.compile('>(.*?)<',re.DOTALL).findall(meta[0])).strip()
				match1 = re.compile('Katalog\xf3w: \\d+ / Plik\xf3w: \\d+').findall(txt)
				match2 = True if 'Filmy:' in txt and 'Rozmiar:' in txt else False
				if match1:
					folder = match1[0]
				elif match2:
					folder = status[0] if status else ''
					plot.append(txt)
			image=''
			if img:
				image = img[0]
				if not 'http' in image:
				   image =  BASEURL + image

			#if PY3:
			#
			#	one = {'href'  : (BASEURL+href_title[0][0]).decode("utf-8"),
			#		'title' : (unicodePLchar(href_title[0][1]).strip()).decode("utf-8") if href_title else '',
			#		'img' : (image).decode("utf-8"),
			#		'folder': (unicodePLchar(folder).strip()).decode("utf-8"),
			#		'duration': (duration[0]).decode("utf-8") if duration else '',
			#		'plot' :(unicodePLchar(plot[0]).strip()).decode("utf-8") if plot else '',
			#		}
			#	
			#else:	
			one = {'href'  : BASEURL+href_title[0][0],
				'title' : unicodePLchar(href_title[0][1]).strip() if href_title else '',
				'img' : image,
				'folder': unicodePLchar(folder).strip(),
				'duration': duration[0] if duration else '',
				'plot' :unicodePLchar(plot[0]).strip() if plot else '',
				}
			if one.get('folder'):
				one['title'] = '[COLOR lightblue]%s[/COLOR] - [COLOR lightgreen]%s[/COLOR]' %(one['title'], one.get('folder'))
			out.append(one)
	return out
def scanUser(url):
	out=[]
	my={}

	content=getUrl(url)

	if 'captcha.png' in content or 'ca-pt-cha.png' in content:
		xbmc.log('[VIDER] CAPTCHA DETECTED', xbmc.LOGWARNING)
		rozwCaptcha(content)
		content=getUrl(url)

	overflow = re.compile('<div class="overflow">(.*?)</div>',re.DOTALL).findall(content)
	clearfix = re.compile('<li class="clearfix w-100-p">(.*?)</li>',re.DOTALL).findall(content)
	if overflow:
	#	overflow=overflow.encode("utf-8") if PY3 else overflow
		out = _get_overflowtype(overflow)
		fileTreeLink = re.compile('<div class="CssTreeValue CssTreeValueMain"><a href="(.*?)"\\s*title="(.*?)"\\s*class="fileTreeLink">').findall(content)
		if fileTreeLink:
			img = re.findall('src="(https://img.vider.info/avatar/.*?)"',content)
			img = img[0] if img else ''
			my = {'href':BASEURL+fileTreeLink[0][0],'title':'[COLOR blue][Kolekcje video][/COLOR]','img':img,'folder':'yes'}
			out.insert(0,my)
	elif clearfix:
		out = _get_clearfixtype(clearfix)
	return out
def search(txt,pg):
	out=[]
	dal=False
	url = 'https://vider.info/search/get'

	payload = {"search_phrase": txt, "search_type": "all", "search_saved": 0, "pages": int(pg), "limit": 0}

	headers = {'User-Agent': UA, 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json', 'Accept': 'application/json, text/javascript, */*; q=0.01', 'Referer': 'https://vider.info/search/all/' + txt, 'Origin': 'https://vider.info'}
	content=getUrl(url,data=payload,headers=headers,is_json=True)
	xbmc.log('@#@contentcontentcontentcontent: %s' % str(content), xbmc.LOGINFO)

	if 'captcha.png' in content or 'ca-pt-cha.png' in content:
		xbmc.log('[VIDER] CAPTCHA DETECTED', xbmc.LOGWARNING)
		rozwCaptcha(content)
		content=getUrl(url,data=payload,headers=headers,is_json=True)
	
	if content:
		xbmc.log("VIDER SEARCH RESPONSE:\n%s" % str(content), xbmc.LOGERROR)

		try:
			data = json.loads(content)
		except Exception as e:
			xbmc.log("JSON ERROR: %s" % str(e), xbmc.LOGERROR)
			xbmc.log("SERVER RESPONSE: %s" % str(content[:1000]), xbmc.LOGERROR)
			return [], False

		pages = data.get('response', {}).get('pages', '')

		if int(pg) < int(pages):
			dal = True

		resp_data_data = data.get('response', {}).get('data_files', {}).get('data', [])

		for item in resp_data_data:
			imgurl = 'https://img.vider.info/i/dtdtdt/7/2/thumb.png'
			idurl = item.get('id_url', '')
			img = imgurl.replace('dtdtdt', idurl)

			one = {
				'href': 'http://vider.info/embed/video/' + item.get('id_url', ''),
				'title': unicodePLchar(item.get('name', '')),
				'img': img,
				'folder': '',
				'duration': item.get('duration', ''),
				'plot': '',
			}

			if one.get('folder'):
				one['title'] = '[COLOR blue]%s[/COLOR] - [COLOR green]%s[/COLOR]' % (
					one['title'],
					one.get('folder')
				)

			out.append(one)

	return out, dal

url='https://vider.info/vid/+fn18xnn'
def getVideoUrls(url):
	# '	\n	returns \n		- ulr http://....\n	'
	if '/vid/' in url:
		url=url.replace('/vid/','/embed/video/')
	video_link=''
	if not '/embed/' in url:
		content = getUrl(url)
		if 'captcha.png' in content or 'ca-pt-cha.png' in content:
			xbmc.log('[VIDER] CAPTCHA DETECTED', xbmc.LOGWARNING)
			rozwCaptcha(content)
			content=getUrl(url)

		embed = re.compile('<div class="video-frame ">[\\s\n]*<iframe src="(/embed/video/.*?)"').findall(content)
		if not embed:
			embed = re.compile('<iframe src="https://vider.info(/embed/video/.*?)"').findall(content)
		if embed:
			url = BASEURL+embed[0]
	content = getUrl(url)
	if 'captcha.png' in content or 'ca-pt-cha.png' in content:
		xbmc.log('[VIDER] CAPTCHA DETECTED', xbmc.LOGWARNING)
		rozwCaptcha(content)
		content=getUrl(url)

	data = re.compile('data-video-url="(.*?)"').findall(content)

	if data:
		data = data[0]

		try:
			decoded = base64.b64decode(data[::-1]).decode('utf-8')
			video_link = decoded + '|Referer={}&User-Agent={}'.format(url, UA)
		except Exception as e:
			xbmc.log('[VIDER] DECODE ERROR: %s' % str(e), xbmc.LOGERROR)
			video_link = ''

	return video_link

def unicodePLchar(txt):
	if not isinstance(txt, str):
		txt = str(txt)

	txt = re.sub(r"&#\d+;", '', txt)

	txt = txt.replace('&lt;h5&gt;', '')
	txt = txt.replace('&lt;/h5&gt;', '')
	txt = txt.replace('&nbsp;', '')
	txt = txt.replace('&lt;br/&gt;', ' ')
	txt = txt.replace('&quot;', '"')
	txt = txt.replace('&amp;quot;', '"')
	txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
	txt = txt.replace('&oacute;','\xc3\xb3').replace('&Oacute;','\xc3\x93')
	txt = txt.replace('&amp;oacute;','\xc3\xb3').replace('&amp;Oacute;','\xc3\x93')
	txt = txt.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	txt = txt.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	txt = txt.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	txt = txt.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	txt = txt.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	txt = txt.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	txt = txt.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	txt = txt.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	txt = txt.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')

	return txt


